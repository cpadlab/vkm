<?php
header("Location: templates/index.html");
?>
