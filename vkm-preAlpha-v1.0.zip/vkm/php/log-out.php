<?php

$fileName = "vkm_tempSesion.ini";
unlink($fileName);

?>
