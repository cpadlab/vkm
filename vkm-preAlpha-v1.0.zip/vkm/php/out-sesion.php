<?php

$fileName = "vkm_tempSesion.ini";
sleep(600);
unlink($fileName);

?>
